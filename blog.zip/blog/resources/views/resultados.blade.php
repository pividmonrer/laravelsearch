@extends('plantilla')

@section('content')

<a class="btn btn-primary btn-lg active" role="button" href="{{ URL::previous() }}">Volver</a>
<div class="row">
    <div class="col-md-7">
        <table class= "table">
                <table class= "table">
                        <tr class="thead-dark">
                            <th>numafi</th>
                            <th>cod_divpol </th>
                            <th>rucemp</th>
                            <th>codsuc</th>
                            <th>codtipemp</th>
                            <th>nomemp</th>
                            <th>telsuc</th>
                            <th>dirsuc</th>
                            <th>faxsuc</th>
                            <th>apenomafi</th>
                            <th>dirafi</th>
                            <th>telafi</th>
                            <th>celular</th>
                            <th>email</th>
                            <th>salario</th>
                            <th>fecingafi</th>
                            <th>fecsalafi</th>
                            <th>ocuafi</th>
                            <th>movi1</th>
                            <th>movi2</th>
                            <th>movi3</th>
                            <th>movi4</th>
                            <th>movi5</th>
                            <th>claro1</th>
                            <th>claro2</th>
                            <th>claro3</th>
                            <th>claro4</th>
                            <th>claro5</th>
                            <th>calif</th>
                            <th>conyuge</th>
                            <th>cedconyuge</th>
                            <th>numero_placa</th>
                            <th>modelo</th>
                            <th>anio</th>
                            <th>tipo</th>
                            <th>operadora</th>      
                        </tr>
                        @foreach ($usuariosBuscar as $item)
                        <tr>
                        <td>{{$item->NUMAFI}}</td>
                        <td>{{$item->COD_DIVPOL}}</td>
                        <td>{{$item->RUCEMP}}</td>
                        <td>{{$item->CODSUC}}</td>
                        <td>{{$item->CODTIPEMP}}</td>
                        <td>{{$item->NOMEMP}}</td>
                        <td>{{$item->TELSUC}}</td>
                        <td>{{$item->DIRSUC}}</td>
                        <td>{{$item->FAXSUC}}</td>
                        <td>{{$item->APENOMAFI}}</td>
                        <td>{{$item->DIRAFI}}</td>
                        <td>{{$item->TELAFI}}</td>
                        <td>{{$item->CELULAR}}</td>
                        <td>{{$item->EMAIL}}</td>
                        <td>{{$item->SALARIO}}</td>
                        <td>{{$item->FECINGAFI}}</td>
                        <td>{{$item->FECSALAFI}}</td>
                        <td>{{$item->OCUAFI}}</td>
                        <td>{{$item->MOVI1}}</td>
                        <td>{{$item->MOVI2}}</td>
                        <td>{{$item->MOVI3}}</td>
                        <td>{{$item->MOVI4}}</td>
                        <td>{{$item->MOVI5}}</td>
                        <td>{{$item->CLARO1}}</td>
                        <td>{{$item->CLARO2}}</td>
                        <td>{{$item->CLARO3}}</td>
                        <td>{{$item->CLARO4}}</td>
                        <td>{{$item->CLARO5}}</td>
                        <td>{{$item->CALIF}}</td>
                        <td>{{$item->CONYUGE}}</td>
                        <td>{{$item->CEDCONYUGE}}</td>
                        <td>{{$item->NUMERO_PLACA}}</td>
                        <td>{{$item->MODELO}}</td>
                        <td>{{$item->ANIO}}</td>
                        <td>{{$item->TIPO}}</td>
                        <td>{{$item->OPERADORA}}</td>
                  </tr>
            @endforeach
        </table>
    </div>
</div>








@endsection