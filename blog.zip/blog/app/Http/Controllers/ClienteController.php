<?php

namespace App\Http\Controllers;

use App\Cliente;
use Illuminate\Http\Request;
use App;
use DB;

class ClienteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clientes = App\Cliente::all();
        return view('inicio', compact('clientes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $clienteAgregar = new Cliente;
        $clienteAgregar->nombre = $request->nombre;
        $clienteAgregar->edad = $request->edad;
        $clienteAgregar->ciudad = $request->ciudad;
        $clienteAgregar->save();
        return back()->with('agregar', 'El cliente se ha agregado correctamente');
    
    }

    public function buscar(Request $request)
    {
        $arreglo = array();
        $arreglo2 = array();
        $nombreBuscar = "nombre=".$request->nombreBuscar; 
        $edadBuscar = "edad=".$request->edadBuscar; 
        $ciudadBuscar = "ciudad=".$request->ciudadBuscar; 
        
        array_push($arreglo, $nombreBuscar, $edadBuscar, $ciudadBuscar);
        foreach($arreglo as $dato)
        {
            $separado = explode("=", $dato);
            if($separado[1] != "")
              {
                  array_push($arreglo2, $dato);
              }
        }

     if(count($arreglo2)==1)
       {
        foreach($arreglo2 as $dato)
        {
              $separado = explode("=", $dato); 

              $clientesBuscar= DB::table('clientes')->where($separado[0], '=', $separado[1])->get();
              return view('resultados', compact('clientesBuscar'));
        }
       }
       else
       {
        $junto = array();
        foreach($arreglo2 as $dato)
        {
            $separado = explode("=", $dato); //nombre Carlos
            $temp = array();
            array_push($temp, $separado[0], "=", $separado[1]);
            array_push($junto, $temp);
        }

           $clientesBuscar = DB::table('clientes')->where($junto)->get();
           return view('resultados', compact('clientesBuscar'));
       }


    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Cliente  $cliente
     * @return \Illuminate\Http\Response
     */
    public function show(Cliente $cliente)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Cliente  $cliente
     * @return \Illuminate\Http\Response
     */
    public function edit(Cliente $cliente)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Cliente  $cliente
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cliente $cliente)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Cliente  $cliente
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cliente $cliente)
    {
        //
    }
}
