<?php

namespace App\Http\Controllers;

use App\Usuario;
use App;
use DB;
use PDF;
use Excel;
use Illuminate\Http\Request; 
use Response;
class UsuarioController extends Controller
{
 /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Campos: (NUMAFI,COD_DIVPOL,RUCEMP,CODSUC,CODTIPEMP,NOMEMP,TELSUC,DIRSUC,FAXSUC,APENOMAFI,DIRAFI,TELAFI,CELULAR,EMAIL,SALARIO,FECINGAFI,FECSALAFI,OCUAFI,MOVI1,MOVI2,MOVI3,MOVI4,MOVI5,CLARO1,CLARO2,CLARO3,CLARO4,CLARO5,CALIF,CONYUGE,CEDCONYUGE,NUMERO_PLACA,MODELO,ANIO,TIPO,OPERADORA)
        $usuarios = App\Usuario::paginate(5);
        return view('inicio', compact('usuarios'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        //
    }
    public function buscar(Request $request)
    {
        $arreglo = array();
        $arreglo2 = array();
        //$numafi, $cod_divpol, $rucemp, $codsuc, $codtipemp,  $rucemp, $numafi,  $cod_divpol, $nomemp, $telsuc, $dirsuc,  $faxsuc,  
        $numafi = "NUMAFI=".$request->numafi; 
        $cod_divpol  = "COD_DIVPOL=".$request->cod_divpol ; 
        $rucemp = "RUCEMP=".$request->rucemp; 
        $codsuc = "CODSUC=".$request->codsuc; 
        $codtipemp  = "CODTIPEMP=".$request->codtipemp;  
        $nomemp = "NOMEMP=".$request->nomemp; 
        $telsuc = "TELSUC=".$request->telsuc; 
        $dirsuc  = "DIRSUC=".$request->dirsuc; 
        $faxsuc  = "FAXSUC=".$request->faxsuc; 
        $apenomafi  = "APENOMAFI=".$request->apenomafi; 
        $dirafi  = "DIRAFI=".$request->dirafi; 
        $telafi  = "TELAFI=".$request->telafi; 
        $celular  = "CELULAR=".$request->celular; 
        $email  = "EMAIL=".$request->email; 
        $salario  = "SALARIO=".$request->salario; 
        $fecingafi  = "FECINGAFI=".$request->fecingafi; 
        $fecsalafi  = "FECSALAFI=".$request->fecsalafi; 
        $ocuafi  = "OCUAFI=".$request->ocuafi; 
        $movi1  = "MOVI1=".$request->movi1; 
        $movi2  = "MOVI2=".$request->movi2; 
        $movi3  = "MOVI3=".$request->movi3; 
        $movi4  = "MOVI4=".$request->movi4; 
        $movi5  = "MOVI5=".$request->movi5; 
        $claro1  = "CLARO1=".$request->claro1;
        $claro2  = "CLARO2=".$request->claro2; 
        $claro3  = "CLARO3=".$request->claro3; 
        $claro4  = "CLARO4=".$request->claro4; 
        $claro5  = "CLARO5=".$request->claro5; 
        $calif  = "CALIF=".$request->calif; 
        $conyuge  = "CONYUGE=".$request->conyuge; 
        $cedconyuge  = "CEDCONYUGE=".$request->cedconyuge; 
        $numero_placa  = "NUMERO_PLACA=".$request->numero_placa; 
        $modelo  = "MODELO=".$request->modelo; 
        $anio  = "ANIO=".$request->anio; 
        $tipo  = "TIPO=".$request->tipo; 
        $operadora  = "OPERADORA=".$request->operadora; 

        array_push($arreglo,$numafi, $cod_divpol,  $rucemp, $codsuc, $codtipemp, $nomemp, $telsuc, $dirsuc, $faxsuc, $apenomafi,  $dirafi , $telafi , $celular, $email, $salario,$fecingafi, $fecsalafi , $ocuafi, $movi1, $movi2, $movi3, $movi4, $movi5, $claro1, $claro2, $claro3, $claro4 , $claro5, $calif, $conyuge, $cedconyuge, $numero_placa, $modelo, $anio, $tipo, $operadora);
        foreach($arreglo as $dato)
        {
            $separado = explode("=", $dato);
            if($separado[1] != "")
              {
                  array_push($arreglo2, $dato);
              }
        }

        $junto = array();
        foreach($arreglo2 as $dato)
        {
            $separado = explode("=", $dato); //nombre Carlos
            $temp = array();
            array_push($temp, $separado[0], "=", $separado[1]);
            array_push($junto, $temp);
        }

           $usuariosBuscar =  App\Usuario::where($junto)->get();
         

           
      switch ($request->input('boton'))
    {
    case 'boton1':
        return view('resultados', compact('usuariosBuscar'));
    break;
    case 'boton2':
         $pdf = PDF::loadView('pdfUsuario',['usuarios'=>$usuariosBuscar])->setOptions(['dpi' => 50, 'defaultFont' => 'sans-serif'])->setPaper('2A0', 'portrait');
        return $pdf->stream('usuarioBusqueda.pdf');
    break;
    case 'boton3':
        $headers = array(
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=file.csv",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        );
    
    //usuariosBuscar
       $columns = array('NUMAFI', 'COD_DIVPOL',  'RUCEMP', 'CODSUC', 'CODTIPEMP', 'NOMEMP', 'TELSUC', 'DIRSUC', 'FAXSUC', 'APENOMAFI',  'DIRAFI' , 'TELAFI' , 'CELULAR', 'EMAIL', 'SALARIO','FECINGAFI', 'FECSALAFI' , 'OCUAFI', 'MOVI1', 'MOVI2', 'MOVI3', 'MOVI4', 'MOVI5', 'CLARO1', 'CLARO2', 'CLARO3', 'CLARO4' , 'CLARO5', 'CALIF', 'CONYUGE', 'CEDCONYUGE', 'NUMERO_PLACA', 'MODELO', 'ANIO', 'TIPO', 'OPERADORA');
    
        $callback = function() use ($usuariosBuscar, $columns)
        {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);
    
            foreach($usuariosBuscar as $usuario) {
                fputcsv($file, array($usuario->NUMAFI, $usuario->COD_DIVPOL, $usuario->RUCEMP, $usuario->CODSUC, $usuario->CODTIPEMP, $usuario->NOMEMP, $usuario->TELSUC, $usuario->DIRSUC, $usuario->FAXSUC, $usuario->APENOMAFI,  $usuario->DIRAFI , $usuario->TELAFI , $usuario->CELULAR, $usuario->EMAIL, $usuario->SALARIO,$usuario->FECINGAFI, $usuario->FECSALAFI , $usuario->OCUAFI, $usuario->MOVI1, $usuario->MOVI2, $usuario->MOVI3, $usuario->MOVI4, $usuario->MOVI5, $usuario->CLARO1, $usuario->CLARO2, $usuario->CLARO3, $usuario->CLARO4 , $usuario->CLARO5, $usuario->CALIF, $usuario->CONYUGE, $usuario->CEDCONYUGE, $usuario->NUMERO_PLACA, $usuario->MODELO, $usuario->ANIO, $usuario->TIPO, $usuario->OPERADORA));
            }
            fclose($file);
        };
        return Response::stream($callback, 200, $headers);
    break;
  }
}
public function export()
{
  
}

    /**
     * Display the specified resource.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function show(Usuario $usuario)
    {
        //
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function edit(Usuario $usuario)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Usuario $usuario)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function destroy(Usuario $usuario)
    {
        //
    }
}
