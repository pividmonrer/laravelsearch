<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7">
     <form action="<?php echo e(route('buscar')); ?>">
     <button type="submit" name = "boton" value = "boton1"  class="btn btn-primary btn-lg">Buscar</button>
     <button type="submit" name = "boton" value = "boton2" class="btn btn-secondary btn-lg" class="btn btn-success btn-block">Exportar Búsqueda a PDF</button>
     <button type="submit" name = "boton" value = "boton3" class="btn btn-secondary btn-lg" class="btn btn-success btn-block">Exportar Búsqueda a CSV</button>
    <table class= "table">
            <tr>
              <th> <input type="text" name="numafi" id="numafi" class="form-control" placeholder="numafi" size="35"></th>
              <th> <input type="text" name="cod_divpol" id="cod_divpol" class="form-control" placeholder="cod_divpol"></th>
              <th> <input type="text" name="rucemp" id="rucemp" class="form-control" placeholder="rucemp"></th>
              <th> <input type="text" name="codsuc" id="codsuc" class="form-control" placeholder="codsuc"></th>
              <th> <input type="text" name="codtipemp" id="codtipemp" class="form-control" placeholder="codtipemp"></th>
              <th> <input type="text" name="nomemp" id="nomemp" class="form-control" placeholder="nomemp"></th>
              <th> <input type="text" name="telsuc" id="telsuc" class="form-control" placeholder="telsuc"></th>
              <th> <input type="text" name="dirsuc" id="dirsuc" class="form-control" placeholder="dirsuc"></th>
              <th> <input type="text" name="faxsuc" id="faxsuc" class="form-control" placeholder="faxsuc"></th>
              <th> <input type="text" name="apenomafi" id="apenomafi" class="form-control" placeholder="apenomafi"></th>
              <th> <input type="text" name="dirafi" id="dirafi" class="form-control" placeholder="dirafi"></th>
              <th> <input type="text" name="telafi" id="telafi" class="form-control" placeholder="telafi"></th>
              <th> <input type="text" name="celular" id="celular" class="form-control" placeholder="celular"></th>
              <th> <input type="text" name="email" id="email" class="form-control" placeholder="email"></th>
              <th> <input type="text" name="salario" id="salario" class="form-control" placeholder="salario"></th>
              <th> <input type="text" name="fecingafi" id="fecingafi" class="form-control" placeholder="fecingafi"></th>
              <th> <input type="text" name="fecsalafi" id="fecsalafi" class="form-control" placeholder="fecsalafi"></th>
              <th> <input type="text" name="ocuafi" id="ocuafi" class="form-control" placeholder="ocuafi"></th>
              <th> <input type="text" name="movi1" id="movi1" class="form-control" placeholder="movi1"></th>
              <th> <input type="text" name="movi2" id="movi2" class="form-control" placeholder="movi2"></th>
              <th> <input type="text" name="movi3" id="movi3" class="form-control" placeholder="movi3"></th>
              <th> <input type="text" name="movi4" id="movi4" class="form-control" placeholder="movi4"></th>
              <th> <input type="text" name="movi5" id="movi5" class="form-control" placeholder="movi5"></th>
              <th> <input type="text" name="claro1" id="claro1" class="form-control" placeholder="claro1"></th>
              <th> <input type="text" name="claro2" id="claro2" class="form-control" placeholder="claro2"></th>
              <th> <input type="text" name="claro3" id="claro3" class="form-control" placeholder="claro3"></th>
              <th> <input type="text" name="claro4" id="claro4" class="form-control" placeholder="claro4"></th>
              <th> <input type="text" name="claro5" id="claro5" class="form-control" placeholder="claro5"></th>
              <th> <input type="text" name="calif" id="calif" class="form-control" placeholder="calif"></th>
              <th> <input type="text" name="conyuge" id="conyuge" class="form-control" placeholder="conyuge"></th>
              <th> <input type="text" name="cedconyuge" id="cedconyuge" class="form-control" placeholder="cedconyuge"></th>
              <th> <input type="text" name="numero_placa" id="numero_placa" class="form-control" placeholder="numero_placa"></th>
              <th> <input type="text" name="modelo" id="modelo" class="form-control" placeholder="modelo"></th>
              <th> <input type="text" name="anio" id="anio" class="form-control" placeholder="anio"></th>
              <th> <input type="text" name="tipo" id="tipo" class="form-control" placeholder="tipo"></th>
              <th> <input type="text" name="operadora" id="operadora" class="form-control" placeholder="operadora"></th>
              
            </form>
            </tr>
            <tr class="thead-dark">
                <th>numafi</th>
                <th>cod_divpol </th>
                <th>rucemp</th>
                <th>codsuc</th>
                <th>codtipemp</th>
                <th>nomemp</th>
                <th>telsuc</th>
                <th>dirsuc</th>
                <th>faxsuc</th>
                <th>apenomafi</th>
                <th>dirafi</th>
                <th>telafi</th>
                <th>celular</th>
                <th>email</th>
                <th>salario</th>
                <th>fecingafi</th>
                <th>fecsalafi</th>
                <th>ocuafi</th>
                <th>movi1</th>
                <th>movi2</th>
                <th>movi3</th>
                <th>movi4</th>
                <th>movi5</th>
                <th>claro1</th>
                <th>claro2</th>
                <th>claro3</th>
                <th>claro4</th>
                <th>claro5</th>
                <th>calif</th>
                <th>conyuge</th>
                <th>cedconyuge</th>
                <th>numero_placa</th>
                <th>modelo</th>
                <th>anio</th>
                <th>tipo</th>
                <th>operadora</th>
                
            </tr>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($item->NUMAFI); ?></td>
                        <td><?php echo e($item->COD_DIVPOL); ?></td>
                        <td><?php echo e($item->RUCEMP); ?></td>
                        <td><?php echo e($item->CODSUC); ?></td>
                        <td><?php echo e($item->CODTIPEMP); ?></td>
                        <td><?php echo e($item->NOMEMP); ?></td>
                        <td><?php echo e($item->TELSUC); ?></td>
                        <td><?php echo e($item->DIRSUC); ?></td>
                        <td><?php echo e($item->FAXSUC); ?></td>
                        <td><?php echo e($item->APENOMAFI); ?></td>
                        <td><?php echo e($item->DIRAFI); ?></td>
                        <td><?php echo e($item->TELAFI); ?></td>
                        <td><?php echo e($item->CELULAR); ?></td>
                        <td><?php echo e($item->EMAIL); ?></td>
                        <td><?php echo e($item->SALARIO); ?></td>
                        <td><?php echo e($item->FECINGAFI); ?></td>
                        <td><?php echo e($item->FECSALAFI); ?></td>
                        <td><?php echo e($item->OCUAFI); ?></td>
                        <td><?php echo e($item->MOVI1); ?></td>
                        <td><?php echo e($item->MOVI2); ?></td>
                        <td><?php echo e($item->MOVI3); ?></td>
                        <td><?php echo e($item->MOVI4); ?></td>
                        <td><?php echo e($item->MOVI5); ?></td>
                        <td><?php echo e($item->CLARO1); ?></td>
                        <td><?php echo e($item->CLARO2); ?></td>
                        <td><?php echo e($item->CLARO3); ?></td>
                        <td><?php echo e($item->CLARO4); ?></td>
                        <td><?php echo e($item->CLARO5); ?></td>
                        <td><?php echo e($item->CALIF); ?></td>
                        <td><?php echo e($item->CONYUGE); ?></td>
                        <td><?php echo e($item->CEDCONYUGE); ?></td>
                        <td><?php echo e($item->NUMERO_PLACA); ?></td>
                        <td><?php echo e($item->MODELO); ?></td>
                        <td><?php echo e($item->ANIO); ?></td>
                        <td><?php echo e($item->TIPO); ?></td>
                        <td><?php echo e($item->OPERADORA); ?></td>
                  </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($usuarios->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/inicio.blade.php ENDPATH**/ ?>