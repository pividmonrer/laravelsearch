<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7">
        <table class= "table">
                <table class= "table">
                        <tr>
                            <th>numafi</th>
                            <th>cod_divpol </th>
                            <th>rucemp</th>
                            <th>codsuc</th>
                            <th>codtipemp</th>
                            <th>nomemp</th>
                            <th>telsuc</th>
                            <th>dirsuc</th>
                            <th>faxsuc</th>
                            <th>apenomafi</th>
                            <th>dirafi</th>
                            <th>telafi</th>
                            <th>celular</th>
                            <th>email</th>
                            <th>salario</th>
                            <th>fecingafi</th>
                            <th>fecsalafi</th>
                            <th>ocuafi</th>
                            <th>movi1</th>
                            <th>movi2</th>
                            <th>movi3</th>
                            <th>movi4</th>
                            <th>movi5</th>
                            <th>claro1</th>
                            <th>claro2</th>
                            <th>claro3</th>
                            <th>claro4</th>
                            <th>claro5</th>
                            <th>calif</th>
                            <th>conyuge</th>
                            <th>cedconyuge</th>
                            <th>numero_placa</th>
                            <th>modelo</th>
                            <th>anio</th>
                            <th>tipo</th>
                            <th>operadora</th>      
                        </tr>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($item->NUMAFI); ?></td>
                        <td><?php echo e($item->COD_DIVPOL); ?></td>
                        <td><?php echo e($item->RUCEMP); ?></td>
                        <td><?php echo e($item->CODSUC); ?></td>
                        <td><?php echo e($item->CODTIPEMP); ?></td>
                        <td><?php echo e($item->NOMEMP); ?></td>
                        <td><?php echo e($item->TELSUC); ?></td>
                        <td><?php echo e($item->DIRSUC); ?></td>
                        <td><?php echo e($item->FAXSUC); ?></td>
                        <td><?php echo e($item->APENOMAFI); ?></td>
                        <td><?php echo e($item->DIRAFI); ?></td>
                        <td><?php echo e($item->TELAFI); ?></td>
                        <td><?php echo e($item->CELULAR); ?></td>
                        <td><?php echo e($item->EMAIL); ?></td>
                        <td><?php echo e($item->SALARIO); ?></td>
                        <td><?php echo e($item->FECINGAFI); ?></td>
                        <td><?php echo e($item->FECSALAFI); ?></td>
                        <td><?php echo e($item->OCUAFI); ?></td>
                        <td><?php echo e($item->MOVI1); ?></td>
                        <td><?php echo e($item->MOVI2); ?></td>
                        <td><?php echo e($item->MOVI3); ?></td>
                        <td><?php echo e($item->MOVI4); ?></td>
                        <td><?php echo e($item->MOVI5); ?></td>
                        <td><?php echo e($item->CLARO1); ?></td>
                        <td><?php echo e($item->CLARO2); ?></td>
                        <td><?php echo e($item->CLARO3); ?></td>
                        <td><?php echo e($item->CLARO4); ?></td>
                        <td><?php echo e($item->CLARO5); ?></td>
                        <td><?php echo e($item->CALIF); ?></td>
                        <td><?php echo e($item->CONYUGE); ?></td>
                        <td><?php echo e($item->CEDCONYUGE); ?></td>
                        <td><?php echo e($item->NUMERO_PLACA); ?></td>
                        <td><?php echo e($item->MODELO); ?></td>
                        <td><?php echo e($item->ANIO); ?></td>
                        <td><?php echo e($item->TIPO); ?></td>
                        <td><?php echo e($item->OPERADORA); ?></td>
                  </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/pdfUsuario.blade.php ENDPATH**/ ?>